<div class="copyrights">
	 <p>Ghuri Firi. All Rights Reserved |  <a href="#">Ghuri Firi</a> </p>
</div>	
